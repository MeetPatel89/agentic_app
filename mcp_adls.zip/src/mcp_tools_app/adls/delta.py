"""Delta Lake helpers built on ``polars.scan_delta`` and ``deltalake``.

Polars handles the heavy lifting for reads (``pl.scan_delta`` accepts
``storage_options`` directly and supports time travel via ``version=``). The
``deltalake.DeltaTable`` class is still used for metadata-only operations
that don't have a Polars equivalent: history, partitions, current version,
file count.
"""

from __future__ import annotations

import datetime as dt
from typing import Any

import polars as pl
from deltalake import DeltaTable

from mcp_tools_app.adls.config import AdlsEnvironment
from mcp_tools_app.adls.credentials import abfs_uri, storage_options
from mcp_tools_app.adls.paths import split_filesystem_key


def _table_uri(env: AdlsEnvironment, path: str) -> str:
    filesystem, key = split_filesystem_key(path)
    return abfs_uri(env, filesystem, key)


def _open_table(env: AdlsEnvironment, path: str, version: int | None = None) -> DeltaTable:
    uri = _table_uri(env, path)
    return DeltaTable(uri, version=version, storage_options=storage_options(env))


def _parse_version_arg(
    version: int | None, timestamp: str | None
) -> int | str | dt.datetime | None:
    """Return a value suitable for ``pl.scan_delta(version=...)``."""
    if version is not None and timestamp is not None:
        raise ValueError("specify at most one of 'version' or 'timestamp'")
    if version is not None:
        return int(version)
    if timestamp is not None:
        return timestamp
    return None


def scan(
    env: AdlsEnvironment,
    path: str,
    *,
    version: int | None = None,
    timestamp: str | None = None,
) -> pl.LazyFrame:
    """Return a ``LazyFrame`` over a Delta table (optionally time travelled)."""
    uri = _table_uri(env, path)
    version_arg = _parse_version_arg(version, timestamp)
    return pl.scan_delta(uri, version=version_arg, storage_options=storage_options(env))


def get_schema(env: AdlsEnvironment, path: str) -> dict[str, Any]:
    """Return ``{format: 'delta', columns: [{name, dtype}], partitions: [...]}``."""
    lf = scan(env, path)
    schema = lf.collect_schema()
    table = _open_table(env, path)
    metadata = table.metadata()
    return {
        "format": "delta",
        "columns": [{"name": name, "dtype": str(dtype)} for name, dtype in schema.items()],
        "partitions": list(metadata.partition_columns or []),
    }


def get_table_info(env: AdlsEnvironment, path: str) -> dict[str, Any]:
    """Return current_version, schema, partitions, files_count, total_size_bytes."""
    table = _open_table(env, path)
    metadata = table.metadata()
    schema_dict = get_schema(env, path)
    files = table.files()
    try:
        add_actions = table.get_add_actions(flatten=True).to_pylist()
        total_bytes = int(sum(int(a.get("size_bytes", 0) or 0) for a in add_actions))
    except Exception:
        total_bytes = None
    return {
        "format": "delta",
        "current_version": int(table.version()),
        "schema": schema_dict["columns"],
        "partitions": list(metadata.partition_columns or []),
        "files_count": len(files),
        "total_size_bytes": total_bytes,
        "table_uri": table.table_uri,
    }


def list_versions(env: AdlsEnvironment, path: str, limit: int | None = 50) -> list[dict[str, Any]]:
    """Return commit history newest-first (capped by ``limit``)."""
    table = _open_table(env, path)
    history = table.history(limit=limit)
    out: list[dict[str, Any]] = []
    for entry in history:
        ts = entry.get("timestamp")
        if isinstance(ts, (int, float)):
            ts_iso = dt.datetime.fromtimestamp(ts / 1000, tz=dt.UTC).isoformat()
        else:
            ts_iso = str(ts) if ts is not None else None
        out.append(
            {
                "version": entry.get("version"),
                "timestamp": ts_iso,
                "operation": entry.get("operation"),
                "operation_metrics": (
                    entry.get("operationMetrics") or entry.get("operation_metrics")
                ),
                "user_name": entry.get("userName") or entry.get("user_name"),
            }
        )
    return out


def read_to_dataframe(
    env: AdlsEnvironment,
    path: str,
    *,
    columns: list[str] | None = None,
    row_limit: int,
    predicate_sql: str | None = None,
    version: int | None = None,
    timestamp: str | None = None,
) -> tuple[pl.DataFrame, str, bool]:
    """Read a Delta table (lazy, with projection / predicate / time-travel)."""
    lf = scan(env, path, version=version, timestamp=timestamp)
    if columns:
        lf = lf.select(columns)
    if predicate_sql:
        lf = lf.sql(f"SELECT * FROM self WHERE {predicate_sql}")
    truncated = False
    if row_limit > 0:
        lf = lf.limit(row_limit + 1)
    df = lf.collect()
    if row_limit > 0 and df.height > row_limit:
        df = df.head(row_limit)
        truncated = True
    return df, "delta", truncated
