"""YAML configuration for the ADLS MCP server.

A single YAML file declares one or more ADLS Gen 2 environments. Each
environment names a subscription (advisory only - the data plane is reached
with the active ``az`` identity), a storage account, and a strict allowlist of
path patterns the server is permitted to expose.

Resolution order for the config file path:

1. Explicit ``--config`` CLI flag
2. ``MCP_ADLS_CONFIG`` environment variable
3. ``./config/adls.yaml`` relative to the current working directory
"""

from __future__ import annotations

import os
from pathlib import Path
from typing import Annotated

import yaml
from pydantic import BaseModel, ConfigDict, Field, field_validator, model_validator


class ConfigError(ValueError):
    """Raised when the YAML config is missing, malformed, or invalid."""


class AdlsDefaults(BaseModel):
    """Server-wide default caps that apply unless overridden per call."""

    model_config = ConfigDict(extra="forbid")

    preview_rows: Annotated[int, Field(gt=0, le=10_000)] = 20
    row_limit: Annotated[int, Field(gt=0, le=1_000_000)] = 1_000
    max_response_bytes: Annotated[int, Field(gt=0, le=10_000_000)] = 200_000


class AdlsEnvironment(BaseModel):
    """A single ADLS Gen 2 environment (e.g. ``dev``, ``stg``, ``prod``)."""

    model_config = ConfigDict(extra="forbid")

    name: Annotated[str, Field(min_length=1)]
    description: str = ""
    subscription_name: Annotated[str, Field(min_length=1)]
    storage_account: Annotated[str, Field(min_length=3, max_length=24)]
    allowed_paths: Annotated[list[str], Field(min_length=1)]

    @field_validator("storage_account")
    @classmethod
    def _validate_storage_account(cls, value: str) -> str:
        if not value.islower() or not value.isalnum():
            raise ValueError(
                "storage_account must be 3-24 lowercase alphanumeric characters"
            )
        return value

    @field_validator("allowed_paths")
    @classmethod
    def _validate_allowed_paths(cls, value: list[str]) -> list[str]:
        cleaned: list[str] = []
        for raw in value:
            pattern = raw.strip().strip("/")
            if not pattern:
                raise ValueError("allowed_paths entries must be non-empty")
            if ".." in pattern.split("/"):
                raise ValueError(f"allowed_paths entry '{raw}' may not contain '..'")
            if "/" not in pattern and "*" not in pattern:
                raise ValueError(
                    f"allowed_paths entry '{raw}' must include a filesystem and key "
                    "(e.g. 'raw/sales/**')"
                )
            cleaned.append(pattern)
        return cleaned


class AdlsConfig(BaseModel):
    """Top-level config: defaults plus a list of environments."""

    model_config = ConfigDict(extra="forbid")

    defaults: AdlsDefaults = Field(default_factory=AdlsDefaults)
    environments: Annotated[list[AdlsEnvironment], Field(min_length=1)]

    @model_validator(mode="after")
    def _unique_env_names(self) -> AdlsConfig:
        seen: set[str] = set()
        for env in self.environments:
            if env.name in seen:
                raise ValueError(f"duplicate environment name: {env.name}")
            seen.add(env.name)
        return self

    def get_environment(self, name: str) -> AdlsEnvironment:
        """Return the environment by name or raise ``ConfigError``."""
        for env in self.environments:
            if env.name == name:
                return env
        known = ", ".join(e.name for e in self.environments)
        raise ConfigError(f"unknown environment '{name}'. Known: {known}")


def resolve_config_path(cli_value: str | None = None) -> Path:
    """Pick the config path per resolution rules; does not check existence."""
    if cli_value:
        return Path(cli_value).expanduser().resolve()
    env_value = os.environ.get("MCP_ADLS_CONFIG")
    if env_value:
        return Path(env_value).expanduser().resolve()
    return (Path.cwd() / "config" / "adls.yaml").resolve()


def load_config(path: str | os.PathLike[str] | None = None) -> AdlsConfig:
    """Load and validate a YAML config from disk.

    ``path`` is resolved via :func:`resolve_config_path` when ``None``.
    """
    resolved = resolve_config_path(str(path) if path is not None else None)
    if not resolved.exists():
        raise ConfigError(f"config file not found: {resolved}")
    try:
        raw = yaml.safe_load(resolved.read_text(encoding="utf-8"))
    except yaml.YAMLError as exc:
        raise ConfigError(f"invalid YAML in {resolved}: {exc}") from exc
    if not isinstance(raw, dict):
        raise ConfigError(f"config root must be a mapping (got {type(raw).__name__})")
    try:
        return AdlsConfig.model_validate(raw)
    except Exception as exc:
        raise ConfigError(f"invalid config in {resolved}: {exc}") from exc
