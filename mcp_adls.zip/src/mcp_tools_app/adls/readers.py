"""Format detection and Polars readers for ADLS Gen 2 objects.

We always go through a single :func:`read_to_dataframe` entry point so the
server tools don't branch on format. Format is detected from the path
extension (with a Delta probe as a special case via ``_delta_log``) and
mapped to the cheapest Polars reader available:

* CSV / TSV     -> ``pl.scan_csv`` (lazy, with column projection and SQL predicate)
* JSON Lines    -> ``pl.scan_ndjson``
* JSON          -> ``pl.read_json`` (single-record or array; eager)
* Parquet       -> ``pl.scan_parquet``
* Excel (xlsx)  -> ``pl.read_excel`` with the ``calamine`` engine (``fastexcel``)
* Text / Log    -> read as a single ``content`` column

Delta is intentionally handled in :mod:`mcp_tools_app.adls.delta`.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Any

import polars as pl

from mcp_tools_app.adls.config import AdlsEnvironment
from mcp_tools_app.adls.credentials import abfs_uri, get_filesystem, storage_options
from mcp_tools_app.adls.paths import split_filesystem_key

TEXT_FORMATS = {"text", "log"}
TABULAR_FORMATS = {"csv", "tsv", "ndjson", "json", "parquet", "excel"}


@dataclass(frozen=True)
class FormatInfo:
    """The detected format plus any Delta-table hint."""

    format: str
    is_delta_table: bool


def detect_format(env: AdlsEnvironment, path: str) -> FormatInfo:
    """Return the format we will use to read ``path``.

    Recognises Delta tables by probing for the ``_delta_log/`` prefix; falls
    back to file-extension mapping otherwise.
    """
    if _looks_like_delta_table(env, path):
        return FormatInfo(format="delta", is_delta_table=True)
    return FormatInfo(format=_format_from_extension(path), is_delta_table=False)


def _format_from_extension(path: str) -> str:
    lower = path.lower()
    if lower.endswith(".csv"):
        return "csv"
    if lower.endswith(".tsv"):
        return "tsv"
    if lower.endswith(".ndjson") or lower.endswith(".jsonl"):
        return "ndjson"
    if lower.endswith(".json"):
        return "json"
    if lower.endswith(".parquet") or lower.endswith(".pq"):
        return "parquet"
    if lower.endswith(".xlsx") or lower.endswith(".xls"):
        return "excel"
    if lower.endswith(".txt") or lower.endswith(".log") or lower.endswith(".md"):
        return "text"
    return "text"


def _looks_like_delta_table(env: AdlsEnvironment, path: str) -> bool:
    filesystem, key = split_filesystem_key(path)
    log_path = f"{filesystem}/{key}/_delta_log" if key else f"{filesystem}/_delta_log"
    try:
        fs = get_filesystem(env)
    except Exception:
        return False
    try:
        return bool(fs.exists(log_path))
    except Exception:
        return False


def get_schema(env: AdlsEnvironment, path: str) -> dict[str, Any]:
    """Return ``{format, columns: [{name, dtype}], ...}`` for ``path``."""
    info = detect_format(env, path)
    if info.is_delta_table:
        from mcp_tools_app.adls import delta as delta_mod

        return delta_mod.get_schema(env, path)

    fmt = info.format
    filesystem, key = split_filesystem_key(path)
    uri = abfs_uri(env, filesystem, key)
    options = storage_options(env)

    if fmt in ("csv", "tsv"):
        lf = pl.scan_csv(uri, storage_options=options, separator="," if fmt == "csv" else "\t")
        schema = lf.collect_schema()
    elif fmt == "ndjson":
        lf = pl.scan_ndjson(uri, storage_options=options)
        schema = lf.collect_schema()
    elif fmt == "json":
        df = _read_json_eager(env, filesystem, key)
        schema = df.schema
    elif fmt == "parquet":
        lf = pl.scan_parquet(uri, storage_options=options)
        schema = lf.collect_schema()
    elif fmt == "excel":
        df = _read_excel_eager(env, filesystem, key, n_rows=1)
        schema = df.schema
    elif fmt in TEXT_FORMATS or fmt == "text":
        schema = pl.Schema({"content": pl.String})
    else:
        raise ValueError(f"unsupported format '{fmt}' for path '{path}'")

    columns = [{"name": name, "dtype": str(dtype)} for name, dtype in schema.items()]
    return {"format": fmt, "columns": columns}


def read_to_dataframe(
    env: AdlsEnvironment,
    path: str,
    *,
    columns: list[str] | None = None,
    row_limit: int,
    predicate_sql: str | None = None,
) -> tuple[pl.DataFrame, str, bool]:
    """Read ``path`` into a DataFrame, applying projection / predicate / limit.

    Returns ``(df, format, source_was_truncated)``.
    ``source_was_truncated`` is set when we know we capped a larger source.
    """
    info = detect_format(env, path)
    if info.is_delta_table:
        from mcp_tools_app.adls import delta as delta_mod

        return delta_mod.read_to_dataframe(
            env, path, columns=columns, row_limit=row_limit, predicate_sql=predicate_sql
        )

    fmt = info.format
    filesystem, key = split_filesystem_key(path)
    uri = abfs_uri(env, filesystem, key)
    options = storage_options(env)

    if fmt in ("csv", "tsv"):
        lf = pl.scan_csv(uri, storage_options=options, separator="," if fmt == "csv" else "\t")
    elif fmt == "ndjson":
        lf = pl.scan_ndjson(uri, storage_options=options)
    elif fmt == "parquet":
        lf = pl.scan_parquet(uri, storage_options=options)
    elif fmt == "json":
        lf = _read_json_eager(env, filesystem, key).lazy()
    elif fmt == "excel":
        df_full = _read_excel_eager(env, filesystem, key)
        lf = df_full.lazy()
    elif fmt in TEXT_FORMATS or fmt == "text":
        text = _read_text_blob(env, filesystem, key)
        df = pl.DataFrame({"content": [text]})
        return df, fmt, False
    else:
        raise ValueError(f"unsupported format '{fmt}' for path '{path}'")

    lf = _apply_projection(lf, columns)
    lf = _apply_predicate(lf, predicate_sql)
    truncated = False
    if row_limit > 0:
        lf = lf.limit(row_limit + 1)
    df = lf.collect()
    if row_limit > 0 and df.height > row_limit:
        df = df.head(row_limit)
        truncated = True
    return df, fmt, truncated


def query_sql_over_sources(
    env: AdlsEnvironment,
    sources: dict[str, str],
    sql: str,
    *,
    row_limit: int,
) -> tuple[pl.DataFrame, bool]:
    """Run a Polars-SQL query over one or more allow-listed sources.

    Each entry of ``sources`` maps a SQL table alias to an env-relative path.
    Paths must have already been allow-listed by the caller.
    """
    ctx = pl.SQLContext(eager=True)
    for alias, path in sources.items():
        info = detect_format(env, path)
        filesystem, key = split_filesystem_key(path)
        if info.is_delta_table:
            from mcp_tools_app.adls import delta as delta_mod

            lf = delta_mod.scan(env, path)
        else:
            uri = abfs_uri(env, filesystem, key)
            options = storage_options(env)
            fmt = info.format
            if fmt in ("csv", "tsv"):
                lf = pl.scan_csv(
                    uri, storage_options=options, separator="," if fmt == "csv" else "\t"
                )
            elif fmt == "ndjson":
                lf = pl.scan_ndjson(uri, storage_options=options)
            elif fmt == "parquet":
                lf = pl.scan_parquet(uri, storage_options=options)
            elif fmt == "json":
                lf = _read_json_eager(env, filesystem, key).lazy()
            elif fmt == "excel":
                lf = _read_excel_eager(env, filesystem, key).lazy()
            else:
                raise ValueError(
                    f"format '{fmt}' for source '{alias}' is not queryable via SQL"
                )
        ctx.register(alias, lf)
    result = ctx.execute(sql)
    df = result if isinstance(result, pl.DataFrame) else result.collect()
    truncated = False
    if row_limit > 0 and df.height > row_limit:
        df = df.head(row_limit)
        truncated = True
    return df, truncated


def _apply_projection(lf: pl.LazyFrame, columns: list[str] | None) -> pl.LazyFrame:
    if not columns:
        return lf
    return lf.select(columns)


def _apply_predicate(lf: pl.LazyFrame, predicate_sql: str | None) -> pl.LazyFrame:
    if not predicate_sql:
        return lf
    sql = f"SELECT * FROM self WHERE {predicate_sql}"
    return lf.sql(sql)


def _read_json_eager(env: AdlsEnvironment, filesystem: str, key: str) -> pl.DataFrame:
    fs = get_filesystem(env)
    blob_path = f"{filesystem}/{key}" if key else filesystem
    with fs.open(blob_path, "rb") as fh:
        data = fh.read()
    try:
        return pl.read_json(data)
    except Exception:
        return pl.read_ndjson(data)


def _read_excel_eager(
    env: AdlsEnvironment, filesystem: str, key: str, *, n_rows: int | None = None
) -> pl.DataFrame:
    fs = get_filesystem(env)
    blob_path = f"{filesystem}/{key}" if key else filesystem
    with fs.open(blob_path, "rb") as fh:
        data = fh.read()
    kwargs: dict[str, Any] = {"engine": "calamine"}
    if n_rows is not None:
        kwargs["read_options"] = {"n_rows": n_rows}
    return pl.read_excel(data, **kwargs)


def _read_text_blob(env: AdlsEnvironment, filesystem: str, key: str) -> str:
    fs = get_filesystem(env)
    blob_path = f"{filesystem}/{key}" if key else filesystem
    with fs.open(blob_path, "rb") as fh:
        data = fh.read()
    try:
        return data.decode("utf-8")
    except UnicodeDecodeError:
        return data.decode("utf-8", errors="replace")
