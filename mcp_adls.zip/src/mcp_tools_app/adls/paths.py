"""Path allowlist and normalization for the ADLS MCP server.

Tool ``path`` arguments use ``<filesystem>/<key>`` notation, where the first
segment is the ADLS Gen 2 filesystem (container) and the rest is the object
key. The storage account is implicit per environment.

Two authorisation modes are exposed:

* :func:`is_readable` - strict ``fnmatch`` match against the env's
  ``allowed_paths`` patterns. Required before any read/preview/schema call.
* :func:`is_listable` - true if ``path`` is on the way to (or inside) at
  least one allowed pattern. Lets the LLM walk down to allowed roots without
  exposing siblings.

Both reject ``..`` traversal, backslashes, and empty segments.
"""

from __future__ import annotations

import fnmatch
import posixpath

from mcp_tools_app.adls.config import AdlsEnvironment


class PathPolicyError(ValueError):
    """Raised when a path is malformed or denied by the env allowlist."""


def normalize_path(path: str) -> str:
    """Return a cleaned ``filesystem/key`` form or raise ``PathPolicyError``.

    * Strips leading/trailing slashes and whitespace.
    * Rejects empty input, backslashes, ``..`` segments, and ``abfs[s]?://``
      / ``https://`` URI prefixes (those would bypass the per-env account).
    """
    if not isinstance(path, str):
        raise PathPolicyError(f"path must be a string, got {type(path).__name__}")
    raw = path.strip()
    if not raw:
        raise PathPolicyError("path must not be empty")
    if "\\" in raw:
        raise PathPolicyError("path must not contain backslashes")
    lowered = raw.lower()
    for scheme in ("abfs://", "abfss://", "https://", "http://", "az://"):
        if lowered.startswith(scheme):
            raise PathPolicyError(
                f"path must be '<filesystem>/<key>' relative to the environment, "
                f"not a {scheme} URI"
            )
    cleaned = raw.strip("/")
    parts = cleaned.split("/")
    for part in parts:
        if part in ("", ".", ".."):
            raise PathPolicyError(f"path '{path}' contains an invalid segment")
    return "/".join(parts)


def split_filesystem_key(path: str) -> tuple[str, str]:
    """Split a normalized path into ``(filesystem, key)``.

    Returns ``(filesystem, "")`` when ``path`` is just a filesystem name.
    """
    cleaned = normalize_path(path)
    parts = cleaned.split("/", 1)
    filesystem = parts[0]
    key = parts[1] if len(parts) > 1 else ""
    return filesystem, key


def is_readable(env: AdlsEnvironment, path: str) -> bool:
    """True iff ``path`` matches at least one of the env's allowed patterns."""
    cleaned = normalize_path(path)
    for pattern in env.allowed_paths:
        if _matches(cleaned, pattern):
            return True
    return False


def is_listable(env: AdlsEnvironment, path: str) -> bool:
    """True iff ``path`` is on the way to, or inside, any allowed pattern.

    This is intentionally looser than :func:`is_readable` so the model can
    discover the structure of allowed subtrees without enumerating siblings
    that are out of scope.
    """
    cleaned = normalize_path(path)
    for pattern in env.allowed_paths:
        if _matches(cleaned, pattern):
            return True
        if _is_ancestor_of_pattern(cleaned, pattern):
            return True
        if _is_descendant_of_pattern(cleaned, pattern):
            return True
    return False


def require_readable(env: AdlsEnvironment, path: str) -> str:
    """Validate ``path`` for read and return its normalized form."""
    cleaned = normalize_path(path)
    if not is_readable(env, cleaned):
        raise PathPolicyError(
            f"path '{cleaned}' is not allowed in environment '{env.name}'"
        )
    return cleaned


def require_listable(env: AdlsEnvironment, path: str) -> str:
    """Validate ``path`` for listing and return its normalized form."""
    cleaned = normalize_path(path)
    if not is_listable(env, cleaned):
        raise PathPolicyError(
            f"path '{cleaned}' is not on any allowed branch in environment "
            f"'{env.name}'"
        )
    return cleaned


def _matches(path: str, pattern: str) -> bool:
    """Segment-aware glob match. ``*`` does not cross ``/``; ``**`` does.

    Each segment is matched with :func:`fnmatch.fnmatchcase` (which works
    inside a single segment); ``**`` can match zero or more whole segments.
    """
    return _double_star_match(path.split("/"), pattern.split("/"))


def _double_star_match(parts: list[str], pat_parts: list[str]) -> bool:
    if not pat_parts:
        return not parts
    head, *rest = pat_parts
    if head == "**":
        if not rest:
            return True
        for i in range(len(parts) + 1):
            if _double_star_match(parts[i:], rest):
                return True
        return False
    if not parts:
        return False
    if not fnmatch.fnmatchcase(parts[0], head):
        return False
    return _double_star_match(parts[1:], rest)


def _is_ancestor_of_pattern(path: str, pattern: str) -> bool:
    """True if ``path`` is a proper prefix of the literal head of ``pattern``."""
    literal_prefix = _literal_prefix(pattern)
    if not literal_prefix:
        return False
    if path == literal_prefix:
        return True
    return literal_prefix.startswith(path + "/")


def _is_descendant_of_pattern(path: str, pattern: str) -> bool:
    """True if ``path`` lives strictly under the pattern's wildcard subtree.

    For ``curated/orders/**`` and path ``curated/orders/2024/jan`` we want
    listability even though the path itself need not match the pattern as a
    *file* (it could be a directory).
    """
    if not pattern.endswith("/**"):
        return False
    prefix = pattern[: -len("/**")]
    if not prefix:
        return False
    if "*" in prefix or "?" in prefix or "[" in prefix:
        prefix_parts = prefix.split("/")
        path_parts = path.split("/")
        if len(path_parts) < len(prefix_parts):
            return False
        for p, pat in zip(path_parts[: len(prefix_parts)], prefix_parts, strict=False):
            if not fnmatch.fnmatchcase(p, pat):
                return False
        return True
    return path == prefix or path.startswith(prefix + "/")


def _literal_prefix(pattern: str) -> str:
    """Return the segments of ``pattern`` up to the first wildcard segment."""
    parts: list[str] = []
    for segment in pattern.split("/"):
        if any(ch in segment for ch in ("*", "?", "[")):
            break
        parts.append(segment)
    return posixpath.join(*parts) if parts else ""
