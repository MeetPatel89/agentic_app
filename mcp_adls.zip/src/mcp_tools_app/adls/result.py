"""DataFrame -> JSON-safe envelope used by every reading tool.

All read/preview/query tools return the same shape so the model can consume
them without branching on tool name. We always cap the response on two axes:

* row count (``row_limit``)
* serialized byte size (``max_response_bytes``)

When either cap fires we set ``truncated = True`` and shrink the row list
until the byte cap is satisfied. The schema is always returned in full.
"""

from __future__ import annotations

import datetime as dt
import json
from decimal import Decimal
from typing import Any

import polars as pl


def schema_to_list(schema: pl.Schema | dict[str, pl.DataType]) -> list[dict[str, str]]:
    """Render a Polars schema as ``[{name, dtype}]`` (stable, JSON-safe)."""
    items: list[tuple[str, Any]]
    if isinstance(schema, pl.Schema):
        items = list(schema.items())
    else:
        items = list(schema.items())
    return [{"name": name, "dtype": str(dtype)} for name, dtype in items]


def _coerce_scalar(value: Any) -> Any:
    if value is None:
        return None
    if isinstance(value, (bool, int, float, str)):
        return value
    if isinstance(value, Decimal):
        return str(value)
    if isinstance(value, (dt.datetime, dt.date, dt.time)):
        return value.isoformat()
    if isinstance(value, dt.timedelta):
        return value.total_seconds()
    if isinstance(value, (bytes, bytearray, memoryview)):
        b = bytes(value)
        try:
            return b.decode("utf-8")
        except UnicodeDecodeError:
            return b.hex()
    if isinstance(value, dict):
        return {str(k): _coerce_scalar(v) for k, v in value.items()}
    if isinstance(value, (list, tuple, set, frozenset)):
        return [_coerce_scalar(v) for v in value]
    return str(value)


def rows_to_json(df: pl.DataFrame) -> list[dict[str, Any]]:
    """Convert a Polars DataFrame to a list of JSON-safe dicts."""
    return [{k: _coerce_scalar(v) for k, v in row.items()} for row in df.iter_rows(named=True)]


def build_envelope(
    *,
    environment: str,
    path: str,
    format_name: str,
    df: pl.DataFrame,
    row_limit: int,
    max_response_bytes: int,
    extra: dict[str, Any] | None = None,
    source_was_truncated: bool = False,
) -> dict[str, Any]:
    """Wrap a DataFrame into the standard tool response envelope.

    Applies ``row_limit`` then iteratively shrinks rows until the serialised
    payload fits ``max_response_bytes``.
    """
    truncated = source_was_truncated
    capped = df
    if capped.height > row_limit:
        capped = capped.head(row_limit)
        truncated = True

    rows = rows_to_json(capped)
    rows, byte_capped = _enforce_byte_cap(rows, max_response_bytes)
    if byte_capped:
        truncated = True

    envelope: dict[str, Any] = {
        "environment": environment,
        "path": path,
        "format": format_name,
        "schema": schema_to_list(capped.schema),
        "rows": rows,
        "row_count": len(rows),
        "truncated": truncated,
    }
    if extra:
        envelope.update(extra)
    return envelope


def _enforce_byte_cap(
    rows: list[dict[str, Any]], max_bytes: int
) -> tuple[list[dict[str, Any]], bool]:
    """Shrink ``rows`` until ``json.dumps(rows)`` fits ``max_bytes``."""
    if not rows:
        return rows, False
    serialized = json.dumps(rows, ensure_ascii=False, default=str)
    if len(serialized.encode("utf-8")) <= max_bytes:
        return rows, False
    low, high = 0, len(rows)
    best = 0
    while low <= high:
        mid = (low + high) // 2
        candidate = rows[:mid]
        size = len(json.dumps(candidate, ensure_ascii=False, default=str).encode("utf-8"))
        if size <= max_bytes:
            best = mid
            low = mid + 1
        else:
            high = mid - 1
    return rows[:best], True
