"""Credential and filesystem caches for the ADLS MCP server.

A single :class:`AzureCliCredential` is shared by the whole process (the
``az`` CLI cache is itself per-user). One :class:`adlfs.AzureBlobFileSystem`
is created per environment on first use and reused afterwards: opening these
is cheap but token acquisition is not, so caching avoids re-issuing tokens
for every tool call.

For ``deltalake`` and Polars' ``scan_*`` calls we also expose
:func:`storage_options` which yields the ``object_store``-compatible dict the
underlying Rust readers expect.
"""

from __future__ import annotations

import threading
from functools import lru_cache
from typing import Any

from azure.identity import AzureCliCredential, ChainedTokenCredential, DefaultAzureCredential

from mcp_tools_app.adls.config import AdlsEnvironment

_credential_lock = threading.Lock()
_credential: ChainedTokenCredential | None = None

_fs_lock = threading.Lock()
_filesystem_cache: dict[str, Any] = {}


def get_credential() -> ChainedTokenCredential:
    """Return the process-wide token credential, building it on first use.

    We prefer :class:`AzureCliCredential` (matches the user's intent of using
    their company laptop's ``az`` login) and fall back to
    :class:`DefaultAzureCredential` to support running this server under MSI
    in CI without code changes.
    """
    global _credential
    if _credential is not None:
        return _credential
    with _credential_lock:
        if _credential is None:
            _credential = ChainedTokenCredential(
                AzureCliCredential(),
                DefaultAzureCredential(exclude_interactive_browser_credential=True),
            )
    return _credential


def account_url(env: AdlsEnvironment) -> str:
    """Return the ABFS ``dfs`` URL prefix for the env's storage account."""
    return f"https://{env.storage_account}.dfs.core.windows.net"


def storage_options(env: AdlsEnvironment) -> dict[str, str]:
    """Return ``object_store`` storage options for Polars / deltalake readers.

    These keys are the ones recognised by the Rust ``object_store`` crate
    that powers ``polars.scan_parquet``, ``polars.scan_csv``, and
    ``deltalake.DeltaTable``.
    """
    return {
        "account_name": env.storage_account,
        "use_azure_cli": "true",
    }


def get_filesystem(env: AdlsEnvironment) -> Any:
    """Return a cached :class:`adlfs.AzureBlobFileSystem` for the env.

    ``adlfs`` is imported lazily so unit tests that don't touch the network
    can still import this module.
    """
    cached = _filesystem_cache.get(env.name)
    if cached is not None:
        return cached
    with _fs_lock:
        cached = _filesystem_cache.get(env.name)
        if cached is not None:
            return cached
        from adlfs import AzureBlobFileSystem

        fs = AzureBlobFileSystem(
            account_name=env.storage_account,
            credential=get_credential(),
        )
        _filesystem_cache[env.name] = fs
        return fs


def abfs_uri(env: AdlsEnvironment, filesystem: str, key: str = "") -> str:
    """Build an ``abfs://`` URI for Polars / deltalake.

    ``deltalake.DeltaTable`` and Polars' ``scan_*`` accept this form, with
    credentials supplied separately via ``storage_options``.
    """
    base = f"abfs://{filesystem}@{env.storage_account}.dfs.core.windows.net"
    if key:
        return f"{base}/{key.lstrip('/')}"
    return base


def reset_caches_for_tests() -> None:
    """Drop the cached credential and filesystem objects (test helper)."""
    global _credential
    with _credential_lock:
        _credential = None
    with _fs_lock:
        _filesystem_cache.clear()


@lru_cache(maxsize=1)
def _module_marker() -> str:
    """Sentinel used by tests to assert this module imported successfully."""
    return "mcp_tools_app.adls.credentials"
