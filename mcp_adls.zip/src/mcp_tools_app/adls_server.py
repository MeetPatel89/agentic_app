"""``mcp-adls`` - FastMCP server exposing Azure Data Lake Gen 2 to MCP hosts.

Designed to be spawned over stdio by VS Code Copilot, Cursor, Claude Desktop,
or any other MCP host. Authentication uses your local ``az`` CLI identity
(``AzureCliCredential``) and a YAML config selects which environments
(dev/stg/prod) are reachable and which path prefixes within them are allowed.

The set of tools is fixed:

* ``list_environments``      - what environments and accounts are exposed.
* ``list_paths``             - directory listing under an allowed branch.
* ``file_info``              - size, mtime, detected format, Delta hint.
* ``get_schema``             - column names + dtypes (Delta included).
* ``preview_rows``           - small head sample.
* ``read_file``              - projection + Polars-SQL predicate + caps.
* ``query_sql``              - Polars SQL over one or more allow-listed paths.
* ``list_delta_versions``    - Delta commit history.
* ``read_delta``             - Delta read with version/timestamp time travel.
* ``get_delta_table_info``   - Delta schema, partitions, files, size, version.
"""

from __future__ import annotations

import argparse
import datetime as dt
import logging
import os
from typing import Any

from dotenv import load_dotenv
from mcp.server.fastmcp import FastMCP

from mcp_tools_app.adls import delta as delta_mod
from mcp_tools_app.adls import readers
from mcp_tools_app.adls.config import (
    AdlsConfig,
    ConfigError,
    load_config,
    resolve_config_path,
)
from mcp_tools_app.adls.credentials import get_filesystem
from mcp_tools_app.adls.paths import (
    PathPolicyError,
    require_listable,
    require_readable,
    split_filesystem_key,
)
from mcp_tools_app.adls.result import build_envelope, schema_to_list

load_dotenv()

logger = logging.getLogger("mcp_tools_app.adls_server")

mcp = FastMCP("adls-gen2")

_config: AdlsConfig | None = None


def _get_config() -> AdlsConfig:
    global _config
    if _config is None:
        _config = load_config()
    return _config


def _set_config(config: AdlsConfig) -> None:
    """Inject a pre-loaded config (used by ``main`` after CLI parsing)."""
    global _config
    _config = config


def _resolve_env(name: str):
    return _get_config().get_environment(name)


def _isoformat(value: Any) -> str | None:
    if value is None:
        return None
    if isinstance(value, dt.datetime):
        if value.tzinfo is None:
            value = value.replace(tzinfo=dt.UTC)
        return value.isoformat()
    if isinstance(value, str):
        return value
    return str(value)


@mcp.tool()
def list_environments() -> dict[str, Any]:
    """List the ADLS environments the server is configured to expose.

    The model should call this first to discover valid ``environment`` names
    (e.g. ``dev``, ``stg``, ``prod``) before invoking any read tool.
    """
    cfg = _get_config()
    return {
        "defaults": {
            "preview_rows": cfg.defaults.preview_rows,
            "row_limit": cfg.defaults.row_limit,
            "max_response_bytes": cfg.defaults.max_response_bytes,
        },
        "environments": [
            {
                "name": env.name,
                "description": env.description,
                "subscription_name": env.subscription_name,
                "storage_account": env.storage_account,
                "allowed_paths": list(env.allowed_paths),
            }
            for env in cfg.environments
        ],
    }


@mcp.tool()
def list_paths(environment: str, path: str) -> dict[str, Any]:
    """List immediate children under ``path`` within ``environment``.

    Args:
        environment: One of the names from ``list_environments``.
        path: ``<filesystem>/<key>`` (e.g. ``raw/sales/2024``). The first
            segment is the ADLS Gen 2 filesystem (container). ``path`` must
            be on a branch covered by the env's allowlist.
    """
    env = _resolve_env(environment)
    cleaned = require_listable(env, path)
    fs = get_filesystem(env)
    try:
        entries = fs.ls(cleaned, detail=True)
    except FileNotFoundError as exc:
        raise FileNotFoundError(f"path '{cleaned}' not found in '{environment}'") from exc
    children: list[dict[str, Any]] = []
    for entry in entries:
        full_name: str = str(entry.get("name", ""))
        rel_name = full_name.lstrip("/")
        children.append(
            {
                "name": rel_name,
                "type": entry.get("type"),
                "size": entry.get("size"),
                "modified": _isoformat(entry.get("last_modified") or entry.get("modified")),
            }
        )
    children.sort(key=lambda item: item["name"])
    return {"environment": environment, "path": cleaned, "children": children}


@mcp.tool()
def file_info(environment: str, path: str) -> dict[str, Any]:
    """Return ``{size, modified, format_detected, is_delta_table}`` for ``path``."""
    env = _resolve_env(environment)
    cleaned = require_readable(env, path)
    fs = get_filesystem(env)
    try:
        info = fs.info(cleaned)
    except FileNotFoundError as exc:
        raise FileNotFoundError(f"path '{cleaned}' not found in '{environment}'") from exc
    detected = readers.detect_format(env, cleaned)
    return {
        "environment": environment,
        "path": cleaned,
        "size": info.get("size"),
        "modified": _isoformat(info.get("last_modified") or info.get("modified")),
        "type": info.get("type"),
        "format_detected": detected.format,
        "is_delta_table": detected.is_delta_table,
    }


@mcp.tool()
def get_schema(environment: str, path: str) -> dict[str, Any]:
    """Return column names and Polars dtypes for ``path`` (Delta-aware)."""
    env = _resolve_env(environment)
    cleaned = require_readable(env, path)
    schema = readers.get_schema(env, cleaned)
    return {"environment": environment, "path": cleaned, **schema}


@mcp.tool()
def preview_rows(environment: str, path: str, n: int | None = None) -> dict[str, Any]:
    """Return a small head sample (default: ``defaults.preview_rows``)."""
    cfg = _get_config()
    env = _resolve_env(environment)
    cleaned = require_readable(env, path)
    limit = n if n is not None and n > 0 else cfg.defaults.preview_rows
    df, fmt, truncated = readers.read_to_dataframe(env, cleaned, row_limit=limit)
    return build_envelope(
        environment=environment,
        path=cleaned,
        format_name=fmt,
        df=df,
        row_limit=limit,
        max_response_bytes=cfg.defaults.max_response_bytes,
        source_was_truncated=truncated,
    )


@mcp.tool()
def read_file(
    environment: str,
    path: str,
    columns: list[str] | None = None,
    row_limit: int | None = None,
    predicate_sql: str | None = None,
) -> dict[str, Any]:
    """Read ``path`` with optional column projection and SQL ``WHERE`` clause.

    Args:
        environment: Env name from ``list_environments``.
        path: ``<filesystem>/<key>``; must match the env's allowlist.
        columns: Optional list of columns to project.
        row_limit: Cap on returned rows (defaults to ``defaults.row_limit``).
        predicate_sql: Optional Polars-SQL ``WHERE`` fragment (e.g.
            ``"region = 'EU' AND amount > 100"``). Runs server-side.
    """
    cfg = _get_config()
    env = _resolve_env(environment)
    cleaned = require_readable(env, path)
    limit = row_limit if row_limit is not None and row_limit > 0 else cfg.defaults.row_limit
    df, fmt, truncated = readers.read_to_dataframe(
        env, cleaned, columns=columns, row_limit=limit, predicate_sql=predicate_sql
    )
    return build_envelope(
        environment=environment,
        path=cleaned,
        format_name=fmt,
        df=df,
        row_limit=limit,
        max_response_bytes=cfg.defaults.max_response_bytes,
        source_was_truncated=truncated,
    )


@mcp.tool()
def query_sql(
    environment: str,
    sources: dict[str, str],
    sql: str,
    row_limit: int | None = None,
) -> dict[str, Any]:
    """Run a Polars-SQL query across one or more allow-listed paths.

    Args:
        environment: Env name from ``list_environments``.
        sources: Mapping ``alias -> path`` (each path is validated against
            the env allowlist). The aliases become SQL table names.
        sql: A Polars-SQL ``SELECT`` statement using those aliases.
        row_limit: Cap on returned rows (default: ``defaults.row_limit``).
    """
    cfg = _get_config()
    env = _resolve_env(environment)
    if not sources:
        raise ValueError("'sources' must contain at least one alias -> path entry")
    cleaned_sources = {alias: require_readable(env, p) for alias, p in sources.items()}
    limit = row_limit if row_limit is not None and row_limit > 0 else cfg.defaults.row_limit
    df, truncated = readers.query_sql_over_sources(
        env, cleaned_sources, sql, row_limit=limit
    )
    envelope = build_envelope(
        environment=environment,
        path=", ".join(cleaned_sources.values()),
        format_name="sql",
        df=df,
        row_limit=limit,
        max_response_bytes=cfg.defaults.max_response_bytes,
        source_was_truncated=truncated,
    )
    envelope["sources"] = cleaned_sources
    envelope["sql"] = sql
    return envelope


@mcp.tool()
def list_delta_versions(
    environment: str, path: str, limit: int | None = 50
) -> dict[str, Any]:
    """Return Delta commit history for ``path`` (newest first)."""
    env = _resolve_env(environment)
    cleaned = require_readable(env, path)
    versions = delta_mod.list_versions(env, cleaned, limit=limit)
    return {"environment": environment, "path": cleaned, "versions": versions}


@mcp.tool()
def read_delta(
    environment: str,
    path: str,
    version: int | None = None,
    timestamp: str | None = None,
    columns: list[str] | None = None,
    row_limit: int | None = None,
    predicate_sql: str | None = None,
) -> dict[str, Any]:
    """Read a Delta table, optionally at a specific version or timestamp.

    Args:
        version: Numeric Delta version (exclusive with ``timestamp``).
        timestamp: ISO-8601 timestamp (exclusive with ``version``).
        columns: Optional column projection.
        row_limit: Cap on returned rows.
        predicate_sql: Polars-SQL ``WHERE`` fragment, e.g.
            ``"event_date >= '2024-01-01'"``.
    """
    cfg = _get_config()
    env = _resolve_env(environment)
    cleaned = require_readable(env, path)
    limit = row_limit if row_limit is not None and row_limit > 0 else cfg.defaults.row_limit
    df, fmt, truncated = delta_mod.read_to_dataframe(
        env,
        cleaned,
        columns=columns,
        row_limit=limit,
        predicate_sql=predicate_sql,
        version=version,
        timestamp=timestamp,
    )
    extra: dict[str, Any] = {}
    if version is not None:
        extra["version"] = version
    if timestamp is not None:
        extra["timestamp"] = timestamp
    return build_envelope(
        environment=environment,
        path=cleaned,
        format_name=fmt,
        df=df,
        row_limit=limit,
        max_response_bytes=cfg.defaults.max_response_bytes,
        extra=extra,
        source_was_truncated=truncated,
    )


@mcp.tool()
def get_delta_table_info(environment: str, path: str) -> dict[str, Any]:
    """Return current version, schema, partitions, file count, and total bytes."""
    env = _resolve_env(environment)
    cleaned = require_readable(env, path)
    info = delta_mod.get_table_info(env, cleaned)
    return {"environment": environment, "path": cleaned, **info}


def _format_startup_summary(cfg: AdlsConfig, config_path: str) -> str:
    env_summary = ", ".join(
        f"{e.name}({e.storage_account}, {len(e.allowed_paths)} allowed)"
        for e in cfg.environments
    )
    return f"config={config_path} environments=[{env_summary}]"


def main() -> None:
    """CLI entry point: parse args, load config, start the FastMCP server."""
    default_transport = os.getenv("MCP_ADLS_TRANSPORT", "stdio").strip().lower()
    default_host = os.getenv("MCP_ADLS_HOST", "127.0.0.1").strip()
    default_port = int(os.getenv("MCP_ADLS_PORT", "8766"))

    parser = argparse.ArgumentParser(
        description=(
            "ADLS Gen 2 MCP server. Reads via Polars + deltalake using "
            "your local 'az' identity. Config from --config / MCP_ADLS_CONFIG / "
            "./config/adls.yaml."
        )
    )
    parser.add_argument(
        "--config", default=None, help="Path to the YAML config (overrides MCP_ADLS_CONFIG)."
    )
    parser.add_argument(
        "--transport",
        choices=["stdio", "sse", "streamable-http"],
        default=default_transport,
        help=f"MCP transport (default: {default_transport}).",
    )
    parser.add_argument(
        "--host", default=default_host, help=f"HTTP bind host (default: {default_host})."
    )
    parser.add_argument(
        "--port",
        type=int,
        default=default_port,
        help=f"HTTP bind port (default: {default_port}).",
    )
    args = parser.parse_args()

    logging.basicConfig(
        level=logging.INFO,
        format="%(asctime)s %(levelname)s %(name)s: %(message)s",
    )

    config_path = resolve_config_path(args.config)
    try:
        cfg = load_config(config_path)
    except ConfigError as exc:
        logger.error("Failed to load config: %s", exc)
        raise SystemExit(2) from exc
    _set_config(cfg)

    logger.info(
        "Starting adls-gen2 (transport=%s host=%s port=%s %s)",
        args.transport,
        args.host,
        args.port,
        _format_startup_summary(cfg, str(config_path)),
    )

    mcp.settings.host = args.host
    mcp.settings.port = args.port
    mcp.run(transport=args.transport)


__all__ = [
    "PathPolicyError",
    "file_info",
    "get_delta_table_info",
    "get_schema",
    "list_delta_versions",
    "list_environments",
    "list_paths",
    "main",
    "mcp",
    "preview_rows",
    "query_sql",
    "read_delta",
    "read_file",
    "schema_to_list",
    "split_filesystem_key",
]
