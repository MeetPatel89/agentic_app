"""Server smoke tests: import + non-network tools against a fixture YAML."""

from __future__ import annotations

from pathlib import Path

import pytest

import mcp_tools_app.adls_server as server


@pytest.fixture(autouse=True)
def _load_fixture_config(sample_yaml: Path) -> None:
    from mcp_tools_app.adls.config import load_config

    server._set_config(load_config(sample_yaml))


def test_server_imports_and_registers_tools() -> None:
    assert server.mcp.name == "adls-gen2"


def test_list_environments_returns_configured_envs() -> None:
    result = server.list_environments()
    names = [e["name"] for e in result["environments"]]
    assert names == ["dev", "prod"]
    assert result["defaults"]["row_limit"] == 50


def test_list_paths_denies_out_of_allowlist() -> None:
    from mcp_tools_app.adls.paths import PathPolicyError

    with pytest.raises(PathPolicyError):
        server.list_paths(environment="dev", path="secrets/passwords.csv")


def test_read_file_denies_out_of_allowlist() -> None:
    from mcp_tools_app.adls.paths import PathPolicyError

    with pytest.raises(PathPolicyError):
        server.read_file(environment="dev", path="secrets/passwords.csv")


def test_unknown_environment_raises() -> None:
    from mcp_tools_app.adls.config import ConfigError

    with pytest.raises(ConfigError, match="unknown environment"):
        server.list_paths(environment="staging", path="raw/sales")
