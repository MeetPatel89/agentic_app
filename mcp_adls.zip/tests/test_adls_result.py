"""Envelope construction: row caps, byte caps, scalar coercion."""

from __future__ import annotations

import datetime as dt
from decimal import Decimal

import polars as pl

from mcp_tools_app.adls.result import build_envelope, rows_to_json, schema_to_list


def _make_df() -> pl.DataFrame:
    return pl.DataFrame(
        {
            "order_id": [1, 2, 3, 4, 5],
            "region": ["EU", "US", "EU", "APAC", "US"],
            "amount": [10.5, 20.0, 30.0, 40.0, 50.0],
        }
    )


def test_schema_to_list_uses_str_dtypes() -> None:
    schema = schema_to_list(_make_df().schema)
    names = {item["name"] for item in schema}
    assert names == {"order_id", "region", "amount"}
    assert all(isinstance(item["dtype"], str) for item in schema)


def test_rows_to_json_coerces_specials() -> None:
    df = pl.DataFrame(
        {
            "when": [dt.datetime(2024, 1, 1, 12, 0, 0)],
            "money": [Decimal("12.34")],
            "bytes": [b"hello"],
        }
    )
    rows = rows_to_json(df)
    assert rows[0]["when"].startswith("2024-01-01T12:00:00")
    assert rows[0]["money"] == "12.34"
    assert rows[0]["bytes"] == "hello"


def test_build_envelope_applies_row_limit() -> None:
    env = build_envelope(
        environment="dev",
        path="raw/sales/2024.csv",
        format_name="csv",
        df=_make_df(),
        row_limit=2,
        max_response_bytes=10_000,
    )
    assert env["row_count"] == 2
    assert env["truncated"] is True
    assert env["format"] == "csv"
    assert env["environment"] == "dev"


def test_build_envelope_preserves_source_truncation_flag() -> None:
    env = build_envelope(
        environment="dev",
        path="raw/sales/2024.csv",
        format_name="csv",
        df=_make_df().head(2),
        row_limit=10,
        max_response_bytes=10_000,
        source_was_truncated=True,
    )
    assert env["row_count"] == 2
    assert env["truncated"] is True


def test_build_envelope_applies_byte_cap() -> None:
    df = pl.DataFrame({"chunk": ["x" * 100] * 50})
    env = build_envelope(
        environment="dev",
        path="raw/sales/big.csv",
        format_name="csv",
        df=df,
        row_limit=100,
        max_response_bytes=500,
    )
    assert env["truncated"] is True
    assert env["row_count"] < 50


def test_build_envelope_passes_extra_fields() -> None:
    env = build_envelope(
        environment="dev",
        path="delta/customer_master",
        format_name="delta",
        df=_make_df().head(1),
        row_limit=10,
        max_response_bytes=10_000,
        extra={"version": 4},
    )
    assert env["version"] == 4
