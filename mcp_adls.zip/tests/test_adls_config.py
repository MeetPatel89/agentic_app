"""YAML config loader and Pydantic validation."""

from __future__ import annotations

from pathlib import Path

import pytest

from mcp_tools_app.adls.config import (
    AdlsConfig,
    ConfigError,
    load_config,
    resolve_config_path,
)


def test_load_valid_config(sample_yaml: Path) -> None:
    cfg = load_config(sample_yaml)
    assert isinstance(cfg, AdlsConfig)
    assert cfg.defaults.preview_rows == 7
    assert cfg.defaults.row_limit == 50
    assert {e.name for e in cfg.environments} == {"dev", "prod"}
    dev = cfg.get_environment("dev")
    assert dev.storage_account == "contosodevdatalake"
    assert dev.allowed_paths == ["raw/sales/**", "curated/orders/**"]


def test_duplicate_environment_names_rejected(tmp_path: Path) -> None:
    bad = tmp_path / "dup.yaml"
    bad.write_text(
        """
environments:
  - name: dev
    subscription_name: A
    storage_account: contosodevdatalake
    allowed_paths: ["raw/**"]
  - name: dev
    subscription_name: B
    storage_account: contosootherdatalake
    allowed_paths: ["raw/**"]
""",
        encoding="utf-8",
    )
    with pytest.raises(ConfigError, match="duplicate environment name"):
        load_config(bad)


def test_missing_file_raises(tmp_path: Path) -> None:
    with pytest.raises(ConfigError, match="config file not found"):
        load_config(tmp_path / "does_not_exist.yaml")


def test_invalid_yaml_raises(tmp_path: Path) -> None:
    bad = tmp_path / "bad.yaml"
    bad.write_text("environments: [oops: : :]", encoding="utf-8")
    with pytest.raises(ConfigError, match="invalid YAML"):
        load_config(bad)


def test_root_must_be_mapping(tmp_path: Path) -> None:
    bad = tmp_path / "list.yaml"
    bad.write_text("- a\n- b\n", encoding="utf-8")
    with pytest.raises(ConfigError, match="must be a mapping"):
        load_config(bad)


def test_storage_account_validation(tmp_path: Path) -> None:
    bad = tmp_path / "acct.yaml"
    bad.write_text(
        """
environments:
  - name: dev
    subscription_name: Contoso-Dev
    storage_account: "BadName!"
    allowed_paths: ["raw/**"]
""",
        encoding="utf-8",
    )
    with pytest.raises(ConfigError):
        load_config(bad)


def test_allowed_paths_rejects_dot_dot(tmp_path: Path) -> None:
    bad = tmp_path / "dd.yaml"
    bad.write_text(
        """
environments:
  - name: dev
    subscription_name: Contoso-Dev
    storage_account: contosodevdatalake
    allowed_paths: ["raw/../secret/**"]
""",
        encoding="utf-8",
    )
    with pytest.raises(ConfigError):
        load_config(bad)


def test_allowed_paths_requires_filesystem(tmp_path: Path) -> None:
    bad = tmp_path / "fs.yaml"
    bad.write_text(
        """
environments:
  - name: dev
    subscription_name: Contoso-Dev
    storage_account: contosodevdatalake
    allowed_paths: ["onlyfs"]
""",
        encoding="utf-8",
    )
    with pytest.raises(ConfigError):
        load_config(bad)


def test_resolve_config_path_priority(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> None:
    cli = tmp_path / "from_cli.yaml"
    env = tmp_path / "from_env.yaml"
    cli.write_text("environments: []", encoding="utf-8")
    env.write_text("environments: []", encoding="utf-8")

    monkeypatch.setenv("MCP_ADLS_CONFIG", str(env))
    assert resolve_config_path(str(cli)) == cli.resolve()
    assert resolve_config_path(None) == env.resolve()

    monkeypatch.delenv("MCP_ADLS_CONFIG", raising=False)
    monkeypatch.chdir(tmp_path)
    fallback = resolve_config_path(None)
    assert fallback.name == "adls.yaml"
    assert fallback.parent.name == "config"


def test_get_environment_unknown_raises(sample_yaml: Path) -> None:
    cfg = load_config(sample_yaml)
    with pytest.raises(ConfigError, match="unknown environment"):
        cfg.get_environment("nope")
