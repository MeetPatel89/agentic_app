"""Allowlist matching, path normalization, and listability semantics."""

from __future__ import annotations

import pytest

from mcp_tools_app.adls.config import AdlsEnvironment
from mcp_tools_app.adls.paths import (
    PathPolicyError,
    is_listable,
    is_readable,
    normalize_path,
    require_readable,
    split_filesystem_key,
)


def test_normalize_strips_slashes_and_whitespace() -> None:
    assert normalize_path("  /raw/sales/2024.csv/ ") == "raw/sales/2024.csv"


def test_normalize_rejects_empty() -> None:
    with pytest.raises(PathPolicyError):
        normalize_path("")
    with pytest.raises(PathPolicyError):
        normalize_path("///")


def test_normalize_rejects_dot_dot() -> None:
    with pytest.raises(PathPolicyError):
        normalize_path("raw/../secret")


def test_normalize_rejects_backslashes() -> None:
    with pytest.raises(PathPolicyError):
        normalize_path("raw\\sales\\2024.csv")


@pytest.mark.parametrize(
    "scheme",
    ["abfs://", "abfss://", "https://", "http://", "az://"],
)
def test_normalize_rejects_uri_schemes(scheme: str) -> None:
    with pytest.raises(PathPolicyError):
        normalize_path(f"{scheme}container/key")


def test_split_filesystem_key_root() -> None:
    assert split_filesystem_key("raw") == ("raw", "")


def test_split_filesystem_key_with_key() -> None:
    assert split_filesystem_key("raw/sales/2024.csv") == ("raw", "sales/2024.csv")


def test_is_readable_double_star(sample_env: AdlsEnvironment) -> None:
    assert is_readable(sample_env, "raw/sales/2024/jan.csv") is True
    assert is_readable(sample_env, "raw/sales") is True
    assert is_readable(sample_env, "curated/orders/year=2024/month=01/part.parquet") is True


def test_is_readable_exact_match(sample_env: AdlsEnvironment) -> None:
    assert is_readable(sample_env, "delta/customer_master") is True


def test_is_readable_single_star(sample_env: AdlsEnvironment) -> None:
    assert is_readable(sample_env, "ref/lookup/regions.csv") is True
    assert is_readable(sample_env, "ref/lookup/sub/regions.csv") is False
    assert is_readable(sample_env, "ref/lookup/regions.parquet") is False


def test_is_readable_rejects_unrelated(sample_env: AdlsEnvironment) -> None:
    assert is_readable(sample_env, "secrets/passwords.csv") is False
    assert is_readable(sample_env, "raw/finance/2024.csv") is False


def test_is_listable_walks_to_allowed(sample_env: AdlsEnvironment) -> None:
    assert is_listable(sample_env, "raw") is True
    assert is_listable(sample_env, "raw/sales") is True
    assert is_listable(sample_env, "curated") is True
    assert is_listable(sample_env, "delta") is True


def test_is_listable_inside_subtree(sample_env: AdlsEnvironment) -> None:
    assert is_listable(sample_env, "curated/orders/year=2024/month=03") is True


def test_is_listable_rejects_unrelated(sample_env: AdlsEnvironment) -> None:
    assert is_listable(sample_env, "secrets") is False
    assert is_listable(sample_env, "raw/finance") is False


def test_require_readable_raises_with_env_name(sample_env: AdlsEnvironment) -> None:
    with pytest.raises(PathPolicyError, match="not allowed in environment 'dev'"):
        require_readable(sample_env, "secrets/x.csv")


def test_require_readable_returns_clean(sample_env: AdlsEnvironment) -> None:
    assert require_readable(sample_env, "/raw/sales/2024.csv/") == "raw/sales/2024.csv"
