"""Shared fixtures for the ADLS MCP server test suite."""

from __future__ import annotations

from pathlib import Path

import pytest

from mcp_tools_app.adls.config import AdlsConfig, AdlsDefaults, AdlsEnvironment


@pytest.fixture
def sample_env() -> AdlsEnvironment:
    return AdlsEnvironment(
        name="dev",
        description="Test dev environment",
        subscription_name="Contoso-Dev",
        storage_account="contosodevdatalake",
        allowed_paths=[
            "raw/sales/**",
            "curated/orders/**",
            "delta/customer_master",
            "ref/lookup/*.csv",
        ],
    )


@pytest.fixture
def sample_config(sample_env: AdlsEnvironment) -> AdlsConfig:
    return AdlsConfig(
        defaults=AdlsDefaults(preview_rows=5, row_limit=10, max_response_bytes=4_000),
        environments=[sample_env],
    )


@pytest.fixture
def sample_yaml(tmp_path: Path) -> Path:
    content = """
defaults:
  preview_rows: 7
  row_limit: 50
  max_response_bytes: 8000

environments:
  - name: dev
    description: "Dev env"
    subscription_name: "Contoso-Dev"
    storage_account: "contosodevdatalake"
    allowed_paths:
      - "raw/sales/**"
      - "curated/orders/**"
  - name: prod
    description: "Prod env"
    subscription_name: "Contoso-Prod"
    storage_account: "contosoproddatalake"
    allowed_paths:
      - "curated/**"
"""
    path = tmp_path / "adls.yaml"
    path.write_text(content, encoding="utf-8")
    return path
