# MCP Tools App

A `uv` Python project of MCP servers. The current focus is **`mcp-adls`** -
an MCP server that exposes Azure Data Lake Storage Gen 2 to MCP hosts (VS
Code Copilot, Cursor, Claude Desktop, etc.) using your local `az` identity,
driven by a YAML config of allow-listed paths per environment, with Polars +
`deltalake` as the read engine.

- Python: `>=3.12,<3.14`
- Transport default: stdio (intended to be spawned by an MCP host)
- Auth: `AzureCliCredential` -> `DefaultAzureCredential` (no secrets in YAML)
- Formats: CSV, TSV, JSON, NDJSON, Parquet, Excel (`xlsx`), text/log, **Delta
  (incl. time travel)**

## ADLS MCP Server (`mcp-adls`)

### Install

```bash
uv sync --extra dev
```

### One-time setup

```bash
az login
az account list --output table
cp config/adls.example.yaml config/adls.yaml
$EDITOR config/adls.yaml
```

The server is read-only by design. Your `az` identity must hold an RBAC role
on each storage account that grants data-plane read (e.g. **Storage Blob
Data Reader** or **Storage Blob Data Contributor**); the YAML never carries
secrets.

### YAML config

Copy [`config/adls.example.yaml`](config/adls.example.yaml) and edit for
your environments. Schema:

```yaml
defaults:
  preview_rows: 20         # default for preview_rows tool
  row_limit: 1000          # default cap on read_file / query_sql / read_delta
  max_response_bytes: 200000   # hard cap on serialised rows in the response

environments:
  - name: dev                          # name the LLM will pass as `environment`
    description: "Development data lake"
    subscription_name: "Contoso-Dev"   # advisory; data plane uses your az identity
    storage_account: "contosodevdatalake"
    allowed_paths:
      - "raw/sales/**"                 # ** = any number of segments
      - "curated/orders/**"
      - "delta/customer_master"        # exact-match path (Delta table root)
      - "ref/lookup/*.csv"             # * = anything within a single segment
```

Config file location is resolved as: `--config` flag > `MCP_ADLS_CONFIG` env
var > `./config/adls.yaml`.

#### Allowlist semantics

Each environment has a list of glob patterns. Two checks run per call:

- **Readable** (`read_file`, `preview_rows`, `get_schema`, `file_info`,
  `read_delta`, `list_delta_versions`, `get_delta_table_info`, `query_sql`)
  - the path must match at least one pattern. `*` does not cross `/`; `**`
  matches any number of segments.
- **Listable** (`list_paths`) - the path may be on the way to, or inside,
  any allowed pattern. This lets the model discover structure without
  exposing siblings outside the allowed branches.

Backslashes, `..`, and `abfs[s]://` / `https://` URI prefixes are rejected
in all path arguments.

### Run it

stdio (this is what an MCP host will spawn for you):

```bash
uv run mcp-adls
uv run mcp-adls --config /path/to/adls.yaml
```

> A stdio server has no UI. After the startup log line it sits silent
> waiting for an MCP client on stdin. To play with it interactively, use
> the MCP Inspector below or wire it into VS Code / Cursor.

HTTP (for the MCP Inspector or HTTP-aware hosts):

```bash
uv run mcp-adls --transport streamable-http --port 8766
# HTTP endpoint: http://127.0.0.1:8766/mcp
```

Inspector:

```bash
npx -y @modelcontextprotocol/inspector
# stdio mode: command = uv, args = "run mcp-adls", cwd = this repo
```

### Wire into VS Code / Cursor

VS Code Copilot reads `mcp.json` from your workspace or user dir. Add:

```jsonc
{
  "servers": {
    "adls": {
      "command": "uv",
      "args": [
        "run",
        "--directory", "/home/nautilus89/projects/mcp_tools_app",
        "mcp-adls"
      ],
      "env": {
        "MCP_ADLS_CONFIG": "/home/nautilus89/projects/mcp_tools_app/config/adls.yaml"
      }
    }
  }
}
```

For Cursor, the same shape lives at `~/.cursor/mcp.json`.

### Tools exposed

All tools take an `environment` argument (one of the names from
`list_environments`) plus a `path` of the form `<filesystem>/<key>`, where
`<filesystem>` is the ADLS Gen 2 container.

| Tool                  | Purpose                                                                 |
| --------------------- | ----------------------------------------------------------------------- |
| `list_environments`   | Lists configured envs, their storage accounts, and allowed paths.       |
| `list_paths`          | Children of a directory (must be on a listable branch).                 |
| `file_info`           | Size, modified time, detected format, Delta hint.                       |
| `get_schema`          | Column names + Polars dtypes (Delta-aware).                             |
| `preview_rows`        | Small head sample.                                                      |
| `read_file`           | Polars read with `columns`, `row_limit`, Polars-SQL `predicate_sql`.    |
| `query_sql`           | Polars-SQL `SELECT` over one or more allow-listed paths (aliased).      |
| `list_delta_versions` | Delta commit history (newest first).                                    |
| `read_delta`          | Delta read with `version=` or `timestamp=` time travel.                 |
| `get_delta_table_info`| Schema, partitions, current version, files count, total size.           |

#### Result shape (every read returns this envelope)

```jsonc
{
  "environment": "dev",
  "path": "curated/orders/2024.parquet",
  "format": "parquet",
  "schema": [{"name": "order_id", "dtype": "Int64"}, ...],
  "rows": [{"order_id": 1, ...}, ...],
  "row_count": 1000,
  "truncated": true     // row_limit or max_response_bytes was hit
}
```

### How environment selection works in a query

The model is responsible for picking the right `environment`. The intended
flow is:

1. Model calls `list_environments` once to see what's available.
2. User says something like *"get me all records from the orders delta lake
   in dev"*. The model picks `environment="dev"` from step 1.
3. Model calls the appropriate read tool with that environment.

### Out of scope

- **No writes / deletes / uploads.** Read-only by design.
- **No ARM / management-plane operations.** `subscription_name` is metadata
  only - the data plane is authorised purely by your `az` identity's RBAC.
- **No auth modes other than `az`** (chain falls back to
  `DefaultAzureCredential` so it works under MSI in CI, but there is no
  service-principal block in the YAML).

### Troubleshooting

| Symptom                                                       | Likely cause / fix                                                                     |
| ------------------------------------------------------------- | -------------------------------------------------------------------------------------- |
| `CredentialUnavailableError: Azure CLI not found`             | Install `az`, then `az login`.                                                         |
| `ClientAuthenticationError: AADSTS...`                        | Your `az` session expired - re-run `az login`.                                         |
| `path '...' is not allowed in environment '...'`              | Add a pattern to the env's `allowed_paths` (or fix the path the model is asking for).  |
| `path '...' is not on any allowed branch in environment ...`  | `list_paths` was called on a directory outside every allowed subtree.                  |
| `config file not found`                                       | Pass `--config`, set `MCP_ADLS_CONFIG`, or create `./config/adls.yaml`.                |
| Slow first call per environment                               | First call warms the credential + filesystem cache; subsequent calls are fast.         |
| `uv run mcp-adls` "hangs" after the startup log               | Expected. stdio servers wait on stdin. Use HTTP mode or the Inspector to test by hand. |

### Tests

```bash
uv run pytest -q
```

Tests in `tests/` cover the config loader, allowlist matcher, response
envelope (row/byte caps, scalar coercion), and a server-import smoke check
against a fixture YAML. They do not require Azure access.
